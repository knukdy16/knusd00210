package Event;
import java.util.Scanner;

import ProductManagement.Product;
import ProductManagement.ProductList;


public class Event {
	private Product LoadedProduct;
	
	
	public void settingSale(String ProductCode, double sale){
		ProductList p_l = null;
		Scanner scan = new Scanner(System.in); 
		
		
		LoadedProduct = p_l.searchProduct(ProductCode);
		if(LoadedProduct == null){
			System.err.println("no item");
		}
		else{
			renewalSale(sale);
			
		}
		
		
		
	}
	private void renewalSale(double sale) {
		
		LoadedProduct.setDiscountRate(sale);
		LoadedProduct.setBuyingPrice();

		System.out.println("renewal Sale");
	}
}
