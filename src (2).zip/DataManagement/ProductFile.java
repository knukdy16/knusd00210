package DataManagement;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.StringTokenizer;

import ProductManagement.Deliver;
import ProductManagement.Product;
import ProductManagement.Store;

public class ProductFile {
	static public void main(String args[]) throws IOException {
		Store[] temp;
		Deliver[] temp2;
		StoreDeliverFile loader = new StoreDeliverFile();
		temp = loader.loadStoreFile();
		for(int i = 0; i < temp.length; i++) {
			System.out.println(temp[i].toString());
		}
		temp2 = loader.loadDeliverFile();
		for(int i=0;i<temp2.length;i++) {
			System.out.println(temp[i].toString());
		}
	}
   public void saveProductFile(Product SaveData) throws IOException{
	   PrintWriter pw = new PrintWriter(new FileWriter("Product.txt", true));
     
       pw.println(SaveData.getName() + "|" + SaveData.getNormalPrice() + "|" + SaveData.getDiscountRate()
       + "|" + SaveData.getNormalPrice() + "|" + SaveData.getBarCode() +"|" + SaveData.getProductCode() + "|" + SaveData.getClient() 
       + "|" + SaveData.getExpirationDate() + "|" + SaveData.getContainer() + "|" + SaveData.getOriginalPrice());
       pw.close();
       // �������� ���� �ø� txt���� �������ּ���
   }
   
   public Product[] loadProductFile() throws IOException{
      Product[] returnValue = null;
      int ProductNumber = 0;
      int i=0;
      
      BufferedReader br = new BufferedReader(new FileReader("Product.txt"));
      while(br.readLine()!=null) {
    	  ProductNumber++;
      }
      try{
    	  br = new BufferedReader(new FileReader("Product.txt"));
      }catch(FileNotFoundException e){
    	  e.printStackTrace();
      }catch(IOException e){
    	  e.printStackTrace();
      }
      returnValue = new Product[ProductNumber];
      for(i=0;i<ProductNumber;i++) {
        
    	 String line = br.readLine();
         if (line==null) break;
         StringTokenizer st = new StringTokenizer(line,"|");
         returnValue[i].setName(st.nextToken());
         returnValue[i].setAmount(Integer.parseInt(st.nextToken()));
         returnValue[i].setNormalPrice(Integer.parseInt(st.nextToken()));
         returnValue[i].setDiscountRate(Integer.parseInt(st.nextToken()));
         returnValue[i].setBuyingPrice();
         returnValue[i].setBarCode(st.nextToken());
         returnValue[i].setProductCode(st.nextToken());
         returnValue[i].setClient(st.nextToken());
         returnValue[i].setExpirationDate(st.nextToken());
         returnValue[i].setContainer(st.nextToken());
         returnValue[i].setOriginalPrice(Integer.parseInt(st.nextToken()));
         System.out.println(line);
      }
  
      br.close();
      
      return returnValue;
   }
}